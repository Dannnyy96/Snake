var express = require("express");
var app = express();
var server = require("http").Server(app);
var io = require("socket.io")(server);

app.use(express.static("public"));

var width = 800;
var height = 600;
var grid = 20;
var score=0;
var snakes = {};
var sockets = {};
var food = [ makeApple() ];
var directions = ["up", "right", "left", "down"];

function reset(snake) {
	Object.assign(snake, makeSnake());
}

function makeApple() {
	return {
		x: Math.floor(Math.random() * (width / grid)) * grid,
		y: Math.floor(Math.random() * (height / grid)) * grid,
	}
}

function makeSnake(socket) {
	return {
		x: (Math.floor(Math.random() * ((width / grid) - 5)) + 10) * grid,
		y: (Math.floor(Math.random() * ((height / grid) - 5)) + 10) * grid,
		direction: directions[Math.floor(Math.random() * directions.length)],
		previous_direction: "right",
		length: 5,
		array: []
	};
}

function moveSnake(snake) {
	//if snake head and snake tail match, reset the game
	for (var i = 0; i < snake.array.length; i++) {
		if (snake.x == snake.array[i].x && snake.y == snake.array[i].y) {
			reset(snake);
		}
	}	
	
	//this is used to delete food off the screen
	var foodToDelete = [];

	//if snake head and food position match, add to snake length, add 1 to the score, delete old food and add new food	
	for (var i = 0; i < food.length; i++) {
		if (snake.x == food[i].x && snake.y == food[i].y) {
			snake.length++;
			score = score + 1;
			foodToDelete.push(i);
			food.push(makeApple());
		}
	}

	for (var i = 0; i < foodToDelete.length; i++) {
		food.splice(foodToDelete[i], 1);
	}
	
	//reset game if snake hits left border
	if (snake.x < 0) {
		reset(snake);
	}
	//reset game if snake hits right border
	if (snake.x > width - grid) {
		reset(snake);
	}
	//reset game if snake hits top border
	if (snake.y < 0) {
		reset(snake);
	}
	//reset game if snake hits bottom border
	if (snake.y > height - grid) {
		reset(snake);
	}

	if (snake.direction != snake.previous_direction) {
		snake.array.unshift({
			x: snake.x,
			y: snake.y,
			direction: snake.direction,
			corner: snake.previous_direction + "-" + snake.direction
		});
	} else {
		snake.array.unshift({
			x: snake.x,
			y: snake.y,
			direction: snake.direction,
			corner: "none"
		});
	}

	snake.array.length = Math.min(snake.array.length, snake.length - 1);
	//if snake is moving, move x position left
	if (snake.direction == "left") {
		snake.x -= grid;
	}
	//if snake is moving right, move x position right
	if (snake.direction == "right") {
		snake.x += grid;
	}
	//if snake is moving up, move y position up
	if (snake.direction == "up") {
		snake.y -= grid;
	}
	//if snake is moving down, move y position down
	if (snake.direction == "down") {
		snake.y += grid;
	}

	snake.previous_direction = snake.direction;
}

setInterval(function() {
	for (var id in snakes) {
		moveSnake(snakes[id]);
	}
	
	// go through each client
	for (var id in sockets) {
		var snakeArray = [];
		
		for (var snakeId in snakes) {
			if (snakeId !== id) {
				snakeArray.push(snakes[snakeId]);
			}
		}
		
		sockets[id].emit("server message", {
			snakes: snakeArray,
			yourSnake: snakes[id],
			food: food
		});
	}
}, 100);


io.on("connection", function (socket) {
	snakes[socket.id] = makeSnake();
	sockets[socket.id] = socket;
	var snake = snakes[socket.id];
	console.log("new user connected");
	
	
	
	socket.on("client message", function (action) {
		//move left
		if (action == "left" && snake.direction != "right") {
			snake.previous_direction = snake.direction;
			snake.direction = "left";
		}
		//move up
		if (action == "up" && snake.direction != "down") {
			snake.previous_direction = snake.direction;
			snake.direction = "up";
		}
		//move right
		if (action == "right" && snake.direction != "left") {
			snake.previous_direction = snake.direction;
			snake.direction = "right";
		}
		//move down
		if (action == "down" && snake.direction != "up") {
			snake.previous_direction = snake.direction;
			snake.direction = "down";
		}
	});
	
	socket.on("disconnect", function() {
		delete snakes[socket.id];
		delete sockets[socket.id];
	});
});

server.listen(8081, function(){
	console.log("Server started.");
});
